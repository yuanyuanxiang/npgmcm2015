load('2d.mat');
result = smmc(data,2,1,2,100,12);
[M,N] = size(data);
y1 = [];
y2 = [];
for i= 1 : N
    if result(i)==1
        y1 = [y1,data(:,i)];
    else
        y2 = [y2,data(:,i)];
    end
end
figure;
plot(y1(1,:),y1(2,:),'m*')
hold on
plot(y2(1,:),y2(2,:),'b.')